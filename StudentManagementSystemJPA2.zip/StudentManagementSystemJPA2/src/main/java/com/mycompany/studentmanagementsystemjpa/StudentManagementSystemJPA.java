/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentmanagementsystemjpa;

/**
 *
 * @author Ashutosh
 */
public class StudentManagementSystemJPA {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
