package com.mycompany.studentmanagementsystemjpa; // Use your actual package name if different

import com.studentmanagement.model.Student;
import com.studentmanagement.util.DatabaseUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StudentDAO {

    private static final Logger logger = LogManager.getLogger(StudentDAO.class);

    // Add a new student to the database
    public boolean addStudent(Student student) {
        String sql = "INSERT INTO students (name, email, department, year) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getName());
            pstmt.setString(2, student.getEmail());
            pstmt.setString(3, student.getDepartment());
            pstmt.setInt(4, student.getYear());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                 logger.info("Student added successfully: {}", student.getEmail());
                 return true;
            } else {
                 logger.warn("Student could not be added: {}", student.getEmail());
                 return false;
            }
        } catch (SQLException e) {
            logger.error("Error adding student " + student.getEmail(), e);
            return false;
        }
    }

    // Retrieve a student by ID
    public Student getStudentById(int id) {
        String sql = "SELECT * FROM students WHERE id = ?";
        Student student = null;
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                student = new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("department"),
                        rs.getInt("year")
                );
            }
             logger.debug("Retrieved student by ID {}: {}", id, student != null ? student.getEmail() : "Not Found");
        } catch (SQLException e) {
            logger.error("Error retrieving student by ID " + id, e);
        }
        return student;
    }

    // Retrieve all students
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Student student = new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("department"),
                        rs.getInt("year")
                );
                students.add(student);
            }
             logger.info("Retrieved {} students", students.size());
        } catch (SQLException e) {
            logger.error("Error retrieving all students", e);
        }
        return students;
    }

    // Update an existing student's information
    public boolean updateStudent(Student student) {
        String sql = "UPDATE students SET name = ?, email = ?, department = ?, year = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getName());
            pstmt.setString(2, student.getEmail());
            pstmt.setString(3, student.getDepartment());
            pstmt.setInt(4, student.getYear());
            pstmt.setInt(5, student.getId());

            int affectedRows = pstmt.executeUpdate();
             if (affectedRows > 0) {
                 logger.info("Student updated successfully: ID {}", student.getId());
                 return true;
             } else {
                 logger.warn("Student with ID {} not found for update.", student.getId());
                 return false;
             }
        } catch (SQLException e) {
            logger.error("Error updating student ID " + student.getId(), e);
            return false;
        }
    }

    // Delete a student by ID
    public boolean deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                 logger.info("Student deleted successfully: ID {}", id);
                 return true;
            } else {
                 logger.warn("Student with ID {} not found for deletion.", id);
                 return false;
            }
        } catch (SQLException e) {
            logger.error("Error deleting student ID " + id, e);
            return false;
        }
    }
}