package com.studentmanagement; // Use your actual package name if different

import com.mycompany.studentmanagementsystemjpa.StudentDAO; // Correct import for DAO
import com.studentmanagement.model.Student;
import com.studentmanagement.util.DatabaseUtil;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StudentManagementApp {
    private static final Logger logger = LogManager.getLogger(StudentManagementApp.class);
    private static final StudentDAO studentDAO = new StudentDAO(); // Use the implemented DAO
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Initialize database table
        try {
            DatabaseUtil.initializeDatabase();
        } catch (RuntimeException e) {
             logger.fatal("Failed to initialize database. Exiting application.", e);
             System.err.println("Database initialization failed. Please check logs. Exiting.");
             return; // Exit if DB setup fails
        }


        logger.info("Student Management Application Started");
        runMenu();
        logger.info("Student Management Application Exiting");
        scanner.close(); // Close scanner when done
    }

    private static void runMenu() {
        int choice;
        do {
            printMenu();
            choice = getUserChoice();

            try {
                switch (choice) {
                    case 1:
                        addStudent();
                        break;
                    case 2:
                        viewStudentById();
                        break;
                    case 3:
                        viewAllStudents();
                        break;
                    case 4:
                        updateStudent();
                        break;
                    case 5:
                        deleteStudent();
                        break;
                    case 0:
                        System.out.println("Exiting application...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                 logger.warn("Invalid input type provided by user.");
                 System.out.println("Invalid input. Please enter numbers where required.");
                 scanner.nextLine(); // Consume the invalid input
            } catch (Exception e) {
                logger.error("An unexpected error occurred in the menu operation.", e);
                System.out.println("An unexpected error occurred. Please check logs.");
            }

            if (choice != 0) {
                System.out.println("\nPress Enter to continue...");
                scanner.nextLine(); // Consume the leftover newline
                scanner.nextLine(); // Wait for user to press Enter
            }

        } while (choice != 0);
    }

    private static void printMenu() {
        System.out.println("\n--- Student Management System ---");
        System.out.println("1. Add New Student");
        System.out.println("2. View Student by ID");
        System.out.println("3. View All Students");
        System.out.println("4. Update Student");
        System.out.println("5. Delete Student");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    private static int getUserChoice() {
        int choice = -1;
        try {
            choice = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
            // Consume the invalid input before the next prompt
        } finally {
             scanner.nextLine(); // Consume newline left-over
        }

        return choice;
    }

    private static void addStudent() {
        System.out.println("\n--- Add New Student ---");
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Department: ");
        String department = scanner.nextLine();
        System.out.print("Enter Year: ");
        int year = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Student student = new Student(name, email, department, year);
        if (studentDAO.addStudent(student)) {
            System.out.println("Student added successfully!");
        } else {
            System.out.println("Failed to add student. Check logs for details (e.g., duplicate email).");
        }
    }

    private static void viewStudentById() {
         System.out.println("\n--- View Student by ID ---");
         System.out.print("Enter Student ID to view: ");
         int id = scanner.nextInt();
         scanner.nextLine(); // Consume newline

         Student student = studentDAO.getStudentById(id);
         if (student != null) {
             System.out.println("Student Found:");
             System.out.println(student);
         } else {
             System.out.println("Student with ID " + id + " not found.");
         }
    }


    private static void viewAllStudents() {
        System.out.println("\n--- View All Students ---");
        List<Student> students = studentDAO.getAllStudents();
        if (students.isEmpty()) {
            System.out.println("No students found in the database.");
        } else {
            System.out.println("Total Students: " + students.size());
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }

    private static void updateStudent() {
        System.out.println("\n--- Update Student ---");
        System.out.print("Enter Student ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Check if student exists before asking for new details
        Student existingStudent = studentDAO.getStudentById(id);
        if (existingStudent == null) {
             System.out.println("Student with ID " + id + " not found.");
             return;
        }

        System.out.println("Enter new details (leave blank to keep current value where applicable):");

        System.out.print("Enter New Name [" + existingStudent.getName() + "]: ");
        String name = scanner.nextLine();
        if (name.trim().isEmpty()) {
            name = existingStudent.getName();
        }

        System.out.print("Enter New Email [" + existingStudent.getEmail() + "]: ");
        String email = scanner.nextLine();
         if (email.trim().isEmpty()) {
            email = existingStudent.getEmail();
        }

        System.out.print("Enter New Department [" + existingStudent.getDepartment() + "]: ");
        String department = scanner.nextLine();
         if (department.trim().isEmpty()) {
            department = existingStudent.getDepartment();
        }

        System.out.print("Enter New Year [" + existingStudent.getYear() + "]: ");
        String yearStr = scanner.nextLine();
        int year;
        if (yearStr.trim().isEmpty()) {
            year = existingStudent.getYear();
        } else {
            try {
                 year = Integer.parseInt(yearStr);
            } catch (NumberFormatException e) {
                 System.out.println("Invalid year format. Update cancelled.");
                 return;
            }

        }


        Student studentToUpdate = new Student(id, name, email, department, year);
        if (studentDAO.updateStudent(studentToUpdate)) {
            System.out.println("Student updated successfully!");
        } else {
            System.out.println("Failed to update student. Check logs.");
        }
    }

    private static void deleteStudent() {
        System.out.println("\n--- Delete Student ---");
        System.out.print("Enter Student ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Optional: Confirm deletion
         System.out.print("Are you sure you want to delete student ID " + id + "? (yes/no): ");
         String confirmation = scanner.nextLine();

         if (confirmation.equalsIgnoreCase("yes")) {
             if (studentDAO.deleteStudent(id)) {
                 System.out.println("Student deleted successfully!");
             } else {
                 System.out.println("Failed to delete student (may not exist). Check logs.");
             }
         } else {
              System.out.println("Deletion cancelled.");
         }

    }
}